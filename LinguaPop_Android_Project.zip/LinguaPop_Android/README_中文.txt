LinguaPop 安卓学习软件（源码项目）

功能：
- 中文界面
- 英语 / 日语双学习路线
- 可设置每天学习 1～20 关
- 固定题库，不随机更换
- 每关 5 题
- XP、爱心、宝石、连续学习天数
- 学习进度自动保存在手机本地
- 原创卡通角色
- 离线可用

如何生成 APK：
1. 安装 Android Studio
2. 选择 Open，打开本文件夹 LinguaPop_Android
3. 等待 Gradle 同步完成
4. 菜单 Build > Build App Bundle(s) / APK(s) > Build APK(s)
5. 生成的 APK 在 app/build/outputs/apk/debug/app-debug.apk

注意：
这个压缩包是完整 Android Studio 项目源码，不是已经编译好的 APK。
当前运行环境没有 Android SDK，所以无法在这里直接编译 APK。
